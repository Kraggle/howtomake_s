<div class="subs-dialog">
	<div class="subs-left">
		<div class="subs-line"></div>
		<div class="subs-wrap">
			<h2>Subscribe For the Latest News &amp; Updates</h2>
			<p>We email you all of the latest topics about making money from home and show you how easy it can be for anyone working from home. Subscribing today will give you a head start against the people who sign up tomorrow!</p>
		</div>
	</div>
	<div class="subs-right">
		<form method="post" class="subs-form">
			<input id="et_pb_signup_firstname" class="input" type="text" placeholder="Name" name="et_pb_signup_firstname">
			<input id="et_pb_signup_email" class="input" type="text" placeholder="Email" name="et_pb_signup_email">
			<span class="et_pb_newsletter_button_text">Subscribe</span>
			<input type="hidden" value="mailchimp" name="et_pb_signup_provider">
			<input type="hidden" value="26e9af0331" name="et_pb_signup_list_id">
			<input type="hidden" value="elegantthemestest" name="et_pb_signup_account_name">
			<input type="hidden" value="true" name="et_pb_signup_ip_address">
		</form>
	</div>
</div>
