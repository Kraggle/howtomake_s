import { jQuery as $ } from './src/jquery3.4.1.js';
import list from './partials/list.js';

$(() => {
	list.build();
});

